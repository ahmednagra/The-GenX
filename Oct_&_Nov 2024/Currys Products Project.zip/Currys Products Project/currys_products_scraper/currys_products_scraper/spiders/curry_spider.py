import os
import glob
import json
from datetime import datetime
from collections import OrderedDict
from urllib.parse import urljoin, quote

from scrapy import Request, Spider
from scrapy.exceptions import CloseSpider


class CurrySpider(Spider):
    name = "curry_products"
    allowed_domains = ["www.currys.co.uk"]
    base_url = 'https://www.currys.co.uk'
    current_dt = datetime.now().strftime("%d%m%Y%H%M")

    custom_settings = {
        'RETRY_TIMES': 5,
        'RETRY_HTTP_CODES': [500, 502, 503, 504, 400, 403, 404, 408],
        'CONCURRENT_REQUESTS': 3,
        'FEED_EXPORTERS': {
            'xlsx': 'scrapy_xlsx.XlsxItemExporter',
        },
        'FEEDS': {
            f'output/Currys Products Details {current_dt}.xlsx': {
                'format': 'xlsx',
                'fields': ['Keyword', 'SKU', 'Title', 'Brand', 'Price', 'Price Currency', 'Availability',
                           'Category', 'Description', 'Features', 'Specifications', 'Images', 'URL']
            }
        }
    }

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # Logs
        os.makedirs('logs', exist_ok=True)
        self.logs_filepath = f'logs/Currys_logs {self.current_dt}.txt'
        self.script_starting_datetime = datetime.now().strftime("%d-%m-%Y %H:%M:%S")
        self.write_logs(f'[INIT] Script started at {self.script_starting_datetime}')

        # Initialize search keywords from the input file
        self.search_keywords = self.get_search_keywords_from_file()

        # Set up proxy key and usage flag
        self.proxy = self.get_scrapeops_api_key_from_file()
        self.location = 'eu'

        self.items_scrapped = 0
        self.scraped_urls = []
        self.duplicates_count = 0

    def start_requests(self):
        # Close spider if proxy key is empty
        if not self.proxy:
            self.write_logs(f'ScrapeApi key not exist in input file. Scraper Closed')
            raise CloseSpider("Proxy key is missing. Closing spider.")

        # Log the total number of search keywords available
        self.write_logs(f'[START_REQUESTS] Number of search keywords: {len(self.search_keywords)}')

        for keyword in self.search_keywords:
            print(f'Search Keyword: {keyword}')
            url = f'https://www.currys.co.uk/search?q={quote(keyword)}&search-button=&lang=en_GB'
            yield Request(url, callback=self.parse,
                          meta={'proxy': self.proxy, 'Keyword': keyword,
                                'handle_httpstatus_all': True})


    def parse(self, response, **kwargs):
        keyword = response.meta.get('Keyword')

        # new url for get the 50 Products
        cgid = response.css('.page-next::attr("data-fullhref")').get('').split('&start=')[0]

        if cgid:
            url = f'https://www.currys.co.uk/search-update-grid?{cgid}&start=0&sz=50&viewtype=listView'
            yield Request(url, callback=self.pagination, dont_filter=True,
                              meta={'handle_httpstatus_all': True,
                                    'Keyword': keyword, 'proxy': self.proxy,})
        else:
            self.write_logs(f'Keyword:{keyword} Not Found the search Update Url value, Keyword scraping skipped.')

    def pagination(self, response):
        keyword = response.meta.get('Keyword')
        try:
            items= response.css('.page-result-count::text, .search-result-count::text').get('').strip()
            self.write_logs(f'Keyword: {keyword} Total "{items}" are found\n')

            if not items:
                self.write_logs(f'Keyword: {keyword} NO product found\n')
                # return

            # Extract unique product URLs
            products_urls = list(set(response.css('.click-beacon[role="columnheader"] > a::attr(href)').getall()))

            for product_url in products_urls:
                url = urljoin(self.base_url, product_url)

                #Avoiding Duplicate Records Scrape
                if url in self.scraped_urls:
                    self.duplicates_count += 1
                    self.write_logs(f'URL already scrapped, Skipped : {url} \n')
                    continue

                yield Request(url, callback=self.parse_product_detail,
                              meta={'proxy': self.proxy, 'Keyword': keyword,
                                    'handle_httpstatus_all': True})

        except Exception as e:
            self.write_logs(f'[PARSE] Error on listing page for keyword "{keyword}": {e}')

    def parse_product_detail(self, response):
        keyword = response.meta.get('Keyword')
        title = ''
        try:
            # Load product data from JSON-LD structured data script
            data_dict = json.loads(response.xpath('//script[@type="application/ld+json" and contains(text(), \'\"@type\":\"Product\"\')]/text()').get(''))


            price = data_dict.get('offers', {}).get('price', '')
            title = response.css('h1.product-name::text').get('').strip() or data_dict.get('name', '')

            # Create item dictionary with product details
            item = OrderedDict()
            item['Keyword'] = keyword
            item['Title'] = title
            item['Description'] = data_dict.get('description', '')
            item['SKU'] = data_dict.get('sku', '')
            item['Category'] = data_dict.get('category', '')
            item['Brand'] = data_dict.get('brand', {}).get('name', '')
            item['Price'] = price
            item['Availability'] ='In Stock' if price else 'Out of Stock'
            item['Price Currency'] = data_dict.get('offers', {}).get('priceCurrency', '')
            item['Images'] = '\n'.join([img.replace('?$l-large$&fmt=auto', '') for img in data_dict.get('image', [])])
            item['Features'] = '\n'.join([item.strip() for item in response.css('.key-features-desktop-tab .item-title ::text').getall()])
            item['Specifications'] = self.get_product_specifications(response, keyword, title)
            item['URL'] = response.url

            self.items_scrapped += 1
            print('Items ae Scrapped: ', self.items_scrapped)

            self.scraped_urls.append(response.url)
            yield item

        except json.JSONDecodeError as e:
            self.write_logs(f'[PARSE_PRODUCT_DETAIL] JSON parsing error for keyword "{keyword}" - {e}')
        except Exception as e:
            self.write_logs(f'[PARSE_PRODUCT_DETAIL] Error for keyword "{keyword}" and title "{title}": {e}')


    def get_scrapeops_api_key_from_file(self):
        key = self.get_input_from_txt(file_path=glob.glob('input/scraperapi_key.txt')[0])
        if not key:
            return ''

        api_endpoint = f'http://scraperapi:{key[0]}@proxy-server.scraperapi.com:8001'
        return api_endpoint

    def get_search_keywords_from_file(self):
        return self.get_input_from_txt(glob.glob('input/search_keywords.txt')[0])

    def get_input_from_txt(self, file_path):
        try:
            with open(file_path, mode='r') as txt_file:
                return [line.strip() for line in txt_file.readlines() if line.strip()]

        except FileNotFoundError:
            self.write_logs(f'[GET_INPUT_FROM_TXT] File not found: {file_path}')
            return []
        except Exception as e:
            self.write_logs(f'[GET_INPUT_FROM_TXT] Error reading file "{file_path}": {e}')
            return []

    def get_product_specifications(self, response, keyword, title):
        try:
            # Initialize spec to collect all specifications as a formatted string
            spec = ''

            # Extract and add the main title of the product specifications
            main_title = ''.join(response.css('#tab2 .productSheet > h3 ::text').getall()).strip()
            spec += main_title + '\n\n'

            # Select all specification sections
            specs_sections = response.css('.tech-specification-table')

            # Loop through each section to process its title and details
            for section in specs_sections:
                section_content  = ''

                # Extract and add the title of each specification section
                section_title = section.css('h3::text').get('')
                section_content  += section_title + '\n'

                # Process each row in the section to extract heading and value
                rows = section.css('.tech-specification-body')
                for row in rows:
                    heading = row.css('.tech-specification-th::text').get('')
                    value = ''.join([text.strip() for text in row.css('.tech-specification-td ::text').getall()])

                    # Format the row as 'Heading: Value'
                    section_content  += f'{heading}: {value}\n'

                # Add the section content to the main spec with a separator
                spec += section_content + '\n'

            return spec
        except Exception as e:
            self.write_logs(f'[GET_PRODUCT_SPECIFICATIONS] Error for keyword "{keyword}" and title "{title}": {e}')
            return ''

    def write_logs(self, log_msg):
        with open(self.logs_filepath, mode='a', encoding='utf-8') as logs_file:
            logs_file.write(f'{log_msg}\n')
            print(log_msg)

    def close(spider, reason):
        spider.write_logs(f'{spider.items_scrapped} Total Products Are Scrapped ')
        spider.write_logs(f'{spider.duplicates_count} Total Duplicate Products found and skipped')
        spider.write_logs(f'Script started at {spider.script_starting_datetime}')
        spider.write_logs(f'Script Stopped at {datetime.now().strftime("%d-%m-%Y %H:%M:%S")}')
