product_info = {}
product_info['key'] = 'value'
print(product_info)